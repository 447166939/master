import React,{Component} from 'react';
import {StyleSheet,View} from 'react-native';
import {observer, inject } from 'mobx-react';
import { toJS } from 'mobx';
import SegmentedControlTab from "react-native-segmented-control-tab";
import appState from './appState';
import {getPixel} from '../../common/util';
@observer
export default class Title extends Component {
    
    render(){
        const {selectedIndex,handleIndexChange}=appState;
        return <SegmentedControlTab
        tabsContainerStyle={styles.tabsContainerStyle}
            tabStyle={styles.tabStyle}
            activeTabStyle={styles.activeTabStyle}
              values={["个人排名", "部门排名"]}
              selectedIndex={selectedIndex}
              onTabPress={handleIndexChange}
        />
    }
}
const styles=StyleSheet.create({
    tabsContainerStyle:{
        width:getPixel(180),
        marginLeft:getPixel(40),
    },
    activeTabStyle:{
        backgroundColor:'#5788ff',
    },
    tabStyle:{
        backgroundColor:'#ffffff'
    }
})
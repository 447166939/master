import { observable, action, computed, autorun, ObservableMap } from 'mobx'

class AppState {
  @observable selectedIndex=0;  
  
  @action
  handleIndexChange(index){
    console.log('hello world')
    this.selectedIndex=index;
  }
}
const appState = new AppState()
export default appState;
